-- Generado por Oracle SQL Developer Data Modeler 22.2.0.165.1149
--   en:        2023-09-22 20:38:58 COT
--   sitio:      Oracle Database 11g
--   tipo:      Oracle Database 11g



DROP TABLE asistentes CASCADE CONSTRAINTS;

DROP TABLE diplomados CASCADE CONSTRAINTS;

DROP TABLE entidades CASCADE CONSTRAINTS;

DROP TABLE expone CASCADE CONSTRAINTS;

DROP TABLE idiomas CASCADE CONSTRAINTS;

DROP TABLE inscripciones CASCADE CONSTRAINTS;

DROP TABLE niveles CASCADE CONSTRAINTS;

DROP TABLE pagos CASCADE CONSTRAINTS;

DROP TABLE tarjetas CASCADE CONSTRAINTS;

DROP TABLE titulos CASCADE CONSTRAINTS;

DROP TABLE universidades CASCADE CONSTRAINTS;

-- predefined type, no DDL - MDSYS.SDO_GEOMETRY

-- predefined type, no DDL - XMLTYPE

CREATE TABLE asistentes (
    id_asistente NUMBER NOT NULL,
    nombres      VARCHAR2(30) NOT NULL,
    apellidos    VARCHAR2(30) NOT NULL,
    fecha_nac    DATE NOT NULL
);

ALTER TABLE asistentes ADD CONSTRAINT asistentes_pk PRIMARY KEY ( id_asistente );

CREATE TABLE diplomados (
    id_diplomado     NUMBER NOT NULL,
    nombre_dip       VARCHAR2(30) NOT NULL,
    niveles_id_nivel NUMBER NOT NULL
);

ALTER TABLE diplomados ADD CONSTRAINT diplomados_pk PRIMARY KEY ( id_diplomado );

CREATE TABLE entidades (
    id_entidad NUMBER NOT NULL,
    entidad    VARCHAR2(60) NOT NULL
);

ALTER TABLE entidades ADD CONSTRAINT entidades_pk PRIMARY KEY ( id_entidad );

CREATE TABLE expone (
    diplomados_id_diplomado NUMBER NOT NULL,
    asistentes_id_asistente NUMBER NOT NULL
);

ALTER TABLE expone ADD CONSTRAINT expone_pk PRIMARY KEY ( diplomados_id_diplomado,
                                                          asistentes_id_asistente );

CREATE TABLE idiomas (
    id_idioma NUMBER NOT NULL,
    idioma    VARCHAR2(30)
);

ALTER TABLE idiomas ADD CONSTRAINT idiomas_pk PRIMARY KEY ( id_idioma );

CREATE TABLE inscripciones (
    id_inscripcion          NUMBER NOT NULL,
    prom_asis               NUMBER,
    nota_final              NUMBER NOT NULL,
    id_asistente            NUMBER NOT NULL,
    diplomados_id_diplomado NUMBER NOT NULL
);

ALTER TABLE inscripciones ADD CONSTRAINT inscripciones_pk PRIMARY KEY ( id_inscripcion );

CREATE TABLE niveles (
    id_nivel                NUMBER NOT NULL,
    niv_escrito             NUMBER NOT NULL,
    niv_oral                NUMBER NOT NULL,
    niv_lectura             NUMBER NOT NULL,
    idiomas_id_idioma       NUMBER NOT NULL,
    asistentes_id_asistente NUMBER NOT NULL
);

ALTER TABLE niveles ADD CONSTRAINT niveles_pk PRIMARY KEY ( id_nivel );

CREATE TABLE pagos (
    id_pagos            NUMBER NOT NULL,
    cuotas              NUMBER NOT NULL,
    id_diplomado        NUMBER NOT NULL,
    tarjetas_id_tarjeta NUMBER NOT NULL
);

ALTER TABLE pagos ADD CONSTRAINT pagos_pk PRIMARY KEY ( id_pagos );

CREATE TABLE tarjetas (
    id_tarjeta   NUMBER NOT NULL,
    fecha_emiti  DATE NOT NULL,
    fecha_exp    DATE NOT NULL,
    id_entidad   NUMBER NOT NULL,
    id_asistente NUMBER NOT NULL
);

ALTER TABLE tarjetas ADD CONSTRAINT tarjetas_pk PRIMARY KEY ( id_tarjeta );

CREATE TABLE titulos (
    id_titulo       NUMBER NOT NULL,
    id_universidad  NUMBER NOT NULL,
    titulo          VARCHAR2(30) NOT NULL,
    fecha_obtencion DATE NOT NULL,
    id_asistente    NUMBER NOT NULL
);

ALTER TABLE titulos ADD CONSTRAINT titulos_pk PRIMARY KEY ( id_titulo,
                                                            id_universidad );

CREATE TABLE universidades (
    id_universidad NUMBER NOT NULL,
    universidad    VARCHAR2(60) NOT NULL
);

ALTER TABLE universidades ADD CONSTRAINT universidades_pk PRIMARY KEY ( id_universidad );

ALTER TABLE niveles
    ADD CONSTRAINT asistente_x_niveles FOREIGN KEY ( asistentes_id_asistente )
        REFERENCES asistentes ( id_asistente );

ALTER TABLE expone
    ADD CONSTRAINT asistentes_x_expositores FOREIGN KEY ( asistentes_id_asistente )
        REFERENCES asistentes ( id_asistente );

ALTER TABLE inscripciones
    ADD CONSTRAINT asistentes_x_inscripciones FOREIGN KEY ( id_asistente )
        REFERENCES asistentes ( id_asistente );

ALTER TABLE tarjetas
    ADD CONSTRAINT asistentes_x_tarjetas FOREIGN KEY ( id_asistente )
        REFERENCES asistentes ( id_asistente );

ALTER TABLE expone
    ADD CONSTRAINT diplomados_x_expositores FOREIGN KEY ( diplomados_id_diplomado )
        REFERENCES diplomados ( id_diplomado );

ALTER TABLE inscripciones
    ADD CONSTRAINT diplomados_x_inscripciones FOREIGN KEY ( diplomados_id_diplomado )
        REFERENCES diplomados ( id_diplomado );

ALTER TABLE pagos
    ADD CONSTRAINT diplomados_x_pagos FOREIGN KEY ( id_diplomado )
        REFERENCES diplomados ( id_diplomado );

ALTER TABLE tarjetas
    ADD CONSTRAINT entidades_x_tarjetas FOREIGN KEY ( id_entidad )
        REFERENCES entidades ( id_entidad );

ALTER TABLE niveles
    ADD CONSTRAINT idiomas_x_niveles FOREIGN KEY ( idiomas_id_idioma )
        REFERENCES idiomas ( id_idioma );

ALTER TABLE diplomados
    ADD CONSTRAINT niveles_x_diplomados FOREIGN KEY ( niveles_id_nivel )
        REFERENCES niveles ( id_nivel );

ALTER TABLE pagos
    ADD CONSTRAINT tarjetas_x_pagos FOREIGN KEY ( tarjetas_id_tarjeta )
        REFERENCES tarjetas ( id_tarjeta );

ALTER TABLE titulos
    ADD CONSTRAINT titulos_asistentes_fk FOREIGN KEY ( id_asistente )
        REFERENCES asistentes ( id_asistente );

ALTER TABLE titulos
    ADD CONSTRAINT universidades_x_titulos FOREIGN KEY ( id_universidad )
        REFERENCES universidades ( id_universidad );



-- Informe de Resumen de Oracle SQL Developer Data Modeler: 
-- 
-- CREATE TABLE                            11
-- CREATE INDEX                             0
-- ALTER TABLE                             24
-- CREATE VIEW                              0
-- ALTER VIEW                               0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           0
-- ALTER TRIGGER                            0
-- CREATE COLLECTION TYPE                   0
-- CREATE STRUCTURED TYPE                   0
-- CREATE STRUCTURED TYPE BODY              0
-- CREATE CLUSTER                           0
-- CREATE CONTEXT                           0
-- CREATE DATABASE                          0
-- CREATE DIMENSION                         0
-- CREATE DIRECTORY                         0
-- CREATE DISK GROUP                        0
-- CREATE ROLE                              0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE SEQUENCE                          0
-- CREATE MATERIALIZED VIEW                 0
-- CREATE MATERIALIZED VIEW LOG             0
-- CREATE SYNONYM                           0
-- CREATE TABLESPACE                        0
-- CREATE USER                              0
-- 
-- DROP TABLESPACE                          0
-- DROP DATABASE                            0
-- 
-- REDACTION POLICY                         0
-- 
-- ORDS DROP SCHEMA                         0
-- ORDS ENABLE SCHEMA                       0
-- ORDS ENABLE OBJECT                       0
-- 
-- ERRORS                                   0
-- WARNINGS                                 0
